<?php
session_start();

if (!isset($_SESSION['username'])) {
  $_SESSION['msg'] = "You must log in first";
  header('location: login.php');
}
if (isset($_GET['logout'])) {
  session_destroy();
  unset($_SESSION['username']);
  header("location: login.php");
}
?>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Simple HTML/CSS Contact Form</title>
      <link rel="stylesheet" href="css/styleAgenda.css">
      link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
      <link rel="stylesheet" href="colorful.css">
      <link rel="stylesheet" href="model.css">
      <script src="model.js"></script>
      <script src="js/navbar-ontop.js"></script>
</head>

<body>

  <nav class=" navbar-expand-md fixed-top navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">
        <b>Parking Like Never Before</b>
      </a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar3SupportedContent" aria-controls="navbar3SupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse text-center justify-content-end" id="navbar3SupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="team.html">Home</a>
          </li>
          <li class="nav-item mx-2 mb-2 my-md-0">
            <a class="nav-link" href="login.php">Login</a>
          </li>
        </ul>
        <a class="btn navbar-btn btn-outline-light" href="map.php">Map</a>
      </div>
    </div>
  </nav>

  <?php
  $b = $_GET['carPlateNumber'];
  $c = $_GET['make-and-model'];
  $d = $_GET['date'];
  $e = $_GET['time'];
  $f = $_GET['timeInterval'];

  ?>
  <div class="container">
  <form id="contact" action="" method="post">
    <h3>Parking Agenda</h3>
    <fieldset>
      <p>Name: <strong><?php echo $_SESSION['username']; ?></strong></p>
    </fieldset>
    <fieldset>
      <p>Car Plate Number: <strong><?php echo $b?></strong>
    </fieldset>
    <fieldset>
      <p>Make and Model: <strong><?php echo $c?></strong>
    </fieldset>
    <fieldset>
      <p>Date: <strong><?php echo $d?></strong>
    </fieldset>
    <fieldset>
      <p>Time: <strong><?php echo $e?></strong>
    </fieldset>
    <fieldset>
      <p>Time Interval: <strong><?php echo $f?></strong>
    </fieldset>
    <fieldset>
      <p>Location: <strong><?php echo $m?></strong>
    </fieldset>

  </form>
</div>
<div class="text-white bg-dark" id="where">
  <div class="container">
    <div class="row">
      <div class="p-5 col-md-12">
        <h3>
          <b>Park Services</b>
        </h3>
        <p class="">Lambton College, Toronto</p>
        <p class="">parkservices@services2u.com</p>
        <p class="mb-3">1800-PARK-0909</p>
        <a href="#" target="_blank">
          <i class="fa d-inline fa-lg mr-3 text-white fa-linkedin"></i>
        </a>
        <a href="#" target="_blank">
          <i class="fa fa-facebook d-inline fa-lg mr-3 text-white"></i>
        </a>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 mt-3">
        <p class="text-center text-muted">© Copyright 2018 Park Services - All rights reserved. </p>
      </div>
    </div>
  </div>
</div>



</body>

</html>
