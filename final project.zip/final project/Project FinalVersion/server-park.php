<?php
session_start();

// initializing variables
$username = "";
$email    = "";
$errors = array();

// connect to the database
$db = mysqli_connect('localhost', 'root', 'root', 'database');

// REGISTER USER
if (isset($_POST['book'])) {
  // receive all input values from the form
  $carPlateNumber = mysqli_real_escape_string($db, $_POST['carPlateNumber']);
  $date = mysqli_real_escape_string($db, $_POST['date']);
  $time = mysqli_real_escape_string($db, $_POST['time']);
  $interval = mysqli_real_escape_string($db, $_POST['interval']);
  $makeAndModel = mysqli_real_escape_string($db, $_POST['makeAndModel']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($carPlateNumber)) { array_push($errors, "Car Plate Number is required"); }
  if (empty($date)) { array_push($errors, "Date is required"); }
  if (empty($time)) { array_push($errors, "Time is required"); }
  if (empty(interval)) { array_push($errors, "Interval is required"); }


  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	$password = md5($password_1);//encrypt the password before saving in the database

  	$query = "INSERT INTO parking (carPlateNumber, makeAndModel, date, time, timeInterval )
  			  VALUES('$carPlateNumber', '$makeAndModel', '$date', '$time', '$interval')";
  	mysqli_query($db, $query);
  	$_SESSION['username'] = $username;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: submitted.php');
  }
}


?>
